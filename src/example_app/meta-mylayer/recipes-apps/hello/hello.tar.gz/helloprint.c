#include <stdio.h>
#include "helloprint.h"
void printHello(void) {
    printf("Hello, World! My first Yocto Project recipe.\n");
    return;
}