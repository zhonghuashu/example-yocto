#include "helloprint.h"
int main() {
    printHello();
    return(0);
}